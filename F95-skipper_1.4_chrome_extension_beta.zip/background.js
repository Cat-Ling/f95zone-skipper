chrome.runtime.onInstalled.addListener(() => {
    console.log("F95Zone Skipper installed!");
    console.log("You gotta be pretty geeky to be here.");
});
